import 'package:flutter/cupertino.dart';

class NavigatorUtils {
  static final nav = GlobalKey<NavigatorState>();
}
